#ifndef RECTANGULO_H
#define RECTANGULO_H
#include <iostream>
#include <math.h>
#include "punto.h"
using namespace std;
class Rectangulo{
	
private:
Punto superiorIzquierdo;
Punto superiorDerecho;
Punto inferiorIzquierdo;
Punto inferiorDerecho;

public:

Rectangulo(){
	int lados=0;
cout << "Se ha creado un rectangulo" << endl;
}

void lado (){
 
 if (lados==4) {
 	cout<<"se ha comprobado que es un rectangulo"<<endl;
 	
 }else{
  cout<<"no se ha comprobado que es un rectangulo"<<endl;
}
 }


void AsignarSupIzq(float x, float y){
	

superiorIzquierdo.asignarX( x);
superiorIzquierdo.asignarY( y);
lados +=1;
}
void AsignarSupDer(float x, float y){
superiorDerecho.asignarX( x);
superiorDerecho.asignarY( y);
lados +=1;

}
 

	

void AsignarInfIzq(float x, float y){
inferiorIzquierdo.asignarX( x);
inferiorIzquierdo.asignarY( y);
lados +=1;
}
void AsignarInfDer(float x, float y){
inferiorDerecho.asignarX( x);
inferiorDerecho.asignarY( y);
lados +=1;
}
float Perimetro(){



float base = abs(inferiorDerecho.obtenerX() - inferiorIzquierdo.obtenerX());
float altura = abs(inferiorDerecho.obtenerY() - superiorIzquierdo.obtenerY());
return (base*2) + (altura*2);
}
float Area(){
float base = abs(inferiorDerecho.obtenerX() - inferiorIzquierdo.obtenerX());
float altura = abs(inferiorDerecho.obtenerY() - superiorIzquierdo.obtenerY());
return (base*altura);
}

};
#endif
