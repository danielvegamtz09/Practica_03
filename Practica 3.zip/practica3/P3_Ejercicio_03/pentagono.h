#ifndef PENTAGONO_H
#define PENTAGONO_H


#include <iostream>
#include <math.h>
#include "punto.h"
using namespace std;
class Pentagono{
private:
Punto superiorIzquierdo;
Punto superiorSuperior;
Punto superiorDerecho;
Punto inferiorIzquierdo;
Punto inferiorDerecho;

public:
Pentagono(){
cout << "Se ha creado un pentagono" << endl;
}




void AsignarSupIzq(float x, float y){
	

superiorIzquierdo.asignarX( x);
superiorIzquierdo.asignarY( y);
}


void AsignarPunta(float x, float y){
	

superiorPunta.asignarX( x);
superiorPunta.asignarY( y);
}

void AsignarSupDer(float x, float y){
superiorDerecho.asignarX( x);
superiorDerecho.asignarY( y);

}
 

	

void AsignarInfIzq(float x, float y){
inferiorIzquierdo.asignarX( x);
inferiorIzquierdo.asignarY( y);
}
void AsignarInfDer(float x, float y){
inferiorDerecho.asignarX( x);
inferiorDerecho.asignarY( y);
}
float Perimetro(){



float base =((inferiorDerecho.obtenerX() - inferiorIzquierdo.obtenerX())*5);
return (base);
}
float Area(){
float peri = ((inferiorDerecho.obtenerX() - inferiorIzquierdo.obtenerX()*5);
float altura = abs(inferiorDerecho.obtenerY() - superiorIzquierdo.obtenerY());
return (base*altura);
}

};
#endif
