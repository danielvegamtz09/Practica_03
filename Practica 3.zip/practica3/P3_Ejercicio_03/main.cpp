#include <iostream>
#include "pentagono.h"
int main(){
Pentagono miP;
miP.AsignarSupIzq(1,5);
miP.AsignarPunta(2.5,8);
miP.AsignarSupDer(6,5);
miP.AsignarInfIzq(2,1);
miP.AsignarInfDer(6,1);


cout << "perimetro del rectangulo es: " << miP.Perimetro() << endl;
cout << "area del rectangulo es: " << miP.Area() << endl;
}
