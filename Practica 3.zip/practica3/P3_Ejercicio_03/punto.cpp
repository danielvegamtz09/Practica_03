#include <iostream>
#include "punto.h"

using std::cout;
using std::endl;

Punto::Punto(float x_coord, float y_coord, float z_coord, float a_coord, float b_coord){
x = x_coord;
y = y_coord;
z = z_coord;
a = a_coord;
b = b_coord;
}
Punto::Punto(){}
void Punto::asignarX(float x_coord){
x = x_coord;
}
void Punto::asignarY(float y_coord){
y = y_coord;
}
void Punto::asignarZ(float z_coord){
z = z_coord;
}
void Punto::asignarA(float a_coord){
a = a_coord;
}
void Punto::asignarB(float b_coord){
b = b_coord;
}



float Punto::obtenerX()const{
return x;
}
float Punto::obtenerY()const{
return y;
}
float Punto::obtenerZ()const{
return z;
}
float Punto::obtenerA()const{
return a;
}
float Punto::obtenerB()const{
return b;
}


void Punto::printData(){

cout << "El punto es: (" << x << ", " << y << ", "<< z << ", "<< a << ", "<<b << ")" << endl;
}


